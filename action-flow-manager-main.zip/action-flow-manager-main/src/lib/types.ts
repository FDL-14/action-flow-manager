
export interface User {
  id: string;
  name: string;
  cpf: string;
  email: string;
  role: 'user' | 'master';
  companyIds?: string[]; // Companies user has access to
  permissions: Permission[];
  password?: string; // Add optional password property
}

export interface Permission {
  id: string;
  name: string;
  description: string;
  canCreate?: boolean;
  canEdit?: boolean;
  canDelete?: boolean;
  canMarkComplete?: boolean;
  canMarkDelayed?: boolean;
  canAddNotes?: boolean;
  canViewReports?: boolean;
  viewAllActions?: boolean;
  canEditUser?: boolean; // New permission for editing users
  canEditAction?: boolean; // New permission for editing actions
}

export interface Company {
  id: string;
  name: string;
  logo?: string;
  address?: string;
  cnpj?: string;
  phone?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Client {
  id: string;
  name: string;
  email?: string;
  phone?: string;
  logo?: string;
  address?: string;
  cnpj?: string;
  companyId: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface Responsible {
  id: string;
  name: string;
  email: string;
  phone?: string;
  department: string;
  role: string;
  type?: 'responsible' | 'requester';
  companyId: string;
  companyName?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ActionNote {
  id: string;
  actionId: string;
  content: string;
  createdBy: string;
  createdAt: Date;
  isDeleted: boolean;
}

export interface Action {
  id: string;
  subject: string;
  description: string;
  status: 'pendente' | 'concluido' | 'atrasado';
  responsibleId: string;
  startDate: Date;
  endDate: Date;
  companyId: string;
  clientId?: string;
  requesterId?: string;
  completedAt?: Date;
  attachments?: string[];
  notes: ActionNote[];
  createdAt: Date;
  updatedAt: Date;
  createdBy?: string; // ID of the user who created the action
  createdByName?: string; // Name of the user who created the action
}

export interface ActionSummary {
  completed: number;
  delayed: number;
  pending: number;
  total: number;
  completionRate: number;
}
